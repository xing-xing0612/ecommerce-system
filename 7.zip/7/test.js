const fs = require('fs');
global.window = { mockData: { categories: [] }, location: { hash: '' } };
global.document = { 
    documentElement: { setAttribute: () => {} },
    getElementById: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {}
};
global.localStorage = { getItem: () => null, setItem: () => {} };

const utilsJs = fs.readFileSync('c:/xampp3/htdocs/7/js/utils.js', 'utf8');
const dataJs = fs.readFileSync('c:/xampp3/htdocs/7/js/data.js', 'utf8');
const storeJs = fs.readFileSync('c:/xampp3/htdocs/7/js/store.js', 'utf8');
const adminJs = fs.readFileSync('c:/xampp3/htdocs/7/js/admin.js', 'utf8');

eval(utilsJs);
eval(dataJs);
eval(storeJs);

global.utils = new Utils();
global.store = new Store();
eval(adminJs);

async function test() {
    try {
        await window.Admin.renderDashboard();
        console.log('Success');
    } catch(e) {
        console.error('ERROR IN RENDER:', e);
    }
}
test();
