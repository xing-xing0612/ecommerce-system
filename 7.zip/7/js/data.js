// Mock Data for the E-Commerce Platform

const mockCategories = [
    { id: 'cat_electronics', name: 'Electronics', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=500&q=80' },
    { id: 'cat_clothing', name: 'Clothing', image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=500&q=80' },
    { id: 'cat_home', name: 'Home & Living', image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=500&q=80' },
    { id: 'cat_accessories', name: 'Accessories', image: 'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?w=500&q=80' }
];

const mockBrands = [
    { id: 'br_apple', name: 'Apple' },
    { id: 'br_sony', name: 'Sony' },
    { id: 'br_nike', name: 'Nike' },
    { id: 'br_ikea', name: 'IKEA' },
    { id: 'br_samsung', name: 'Samsung' }
];

const mockProducts = [
    {
        id: 'p_001',
        name: 'Aura Pro Noise Cancelling Headphones',
        category: 'cat_electronics',
        brand: 'br_sony',
        price: 299.99,
        originalPrice: 349.99,
        rating: 4.8,
        reviews: 124,
        isNew: true,
        stock: 50,
        description: 'Experience industry-leading noise cancellation with the Aura Pro. Dual noise sensor technology and the QN1 processor work together to cancel out the world around you.',
        features: ['Active Noise Cancellation', '30-hour battery life', 'Touch sensor controls', 'Voice assistant compatible'],
        images: [
            'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=800&q=80',
            'https://images.unsplash.com/photo-1612444530582-fc66183b16f7?w=800&q=80'
        ],
        colors: ['#000000', '#F5F5DC'],
        sizes: []
    },
    {
        id: 'p_002',
        name: 'Minimalist Smart Watch',
        category: 'cat_electronics',
        brand: 'br_apple',
        price: 199.50,
        originalPrice: null,
        rating: 4.5,
        reviews: 89,
        isNew: false,
        stock: 120,
        description: 'A beautifully designed smart watch that tracks your fitness, monitors your heart rate, and keeps you connected without the bulk.',
        features: ['Heart rate monitoring', 'Water resistant', 'OLED display', '7-day battery'],
        images: [
            'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=80',
            'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&q=80'
        ],
        colors: ['#000000', '#C0C0C0', '#FFC0CB'],
        sizes: []
    },
    {
        id: 'p_003',
        name: 'Essential Cotton T-Shirt',
        category: 'cat_clothing',
        brand: 'br_nike',
        price: 29.99,
        originalPrice: 35.00,
        rating: 4.2,
        reviews: 256,
        isNew: false,
        stock: 500,
        description: 'The perfect everyday t-shirt. Made from 100% organic cotton, it provides maximum comfort and breathability.',
        features: ['100% Organic Cotton', 'Pre-shrunk', 'Crew neck', 'Regular fit'],
        images: [
            'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80',
            'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&q=80'
        ],
        colors: ['#FFFFFF', '#000000', '#000080', '#808080'],
        sizes: ['S', 'M', 'L', 'XL']
    },
    {
        id: 'p_004',
        name: 'Modern Accent Chair',
        category: 'cat_home',
        brand: 'br_ikea',
        price: 159.00,
        originalPrice: null,
        rating: 4.9,
        reviews: 42,
        isNew: true,
        stock: 15,
        description: 'Add a touch of mid-century modern style to your living room with this elegant accent chair featuring solid wood legs and premium upholstery.',
        features: ['Solid wood legs', 'High-density foam', 'Premium fabric', 'Easy assembly'],
        images: [
            'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=800&q=80',
            'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=800&q=80'
        ],
        colors: ['#FFD700', '#808080', '#008080'],
        sizes: []
    },
    {
        id: 'p_005',
        name: 'Ultra-Slim 4K Monitor',
        category: 'cat_electronics',
        brand: 'br_samsung',
        price: 349.99,
        originalPrice: 429.99,
        rating: 4.7,
        reviews: 112,
        isNew: false,
        stock: 30,
        description: 'Stunning 4K resolution in an ultra-slim design. Perfect for creators and professionals who need accurate colors and crisp details.',
        features: ['4K UHD Resolution', 'IPS Panel', 'HDR10 Support', 'AMD FreeSync'],
        images: [
            'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800&q=80'
        ],
        colors: ['#000000'],
        sizes: []
    },
    {
        id: 'p_006',
        name: 'Premium Leather Wallet',
        category: 'cat_accessories',
        brand: 'br_nike',
        price: 45.00,
        originalPrice: null,
        rating: 4.6,
        reviews: 78,
        isNew: true,
        stock: 85,
        description: 'Handcrafted from full-grain leather, this minimalist wallet holds up to 8 cards and folded cash while maintaining a slim profile.',
        features: ['Full-grain leather', 'RFID blocking', 'Holds 8 cards', 'Slim profile'],
        images: [
            'https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&q=80'
        ],
        colors: ['#8B4513', '#000000'],
        sizes: []
    },
    {
        id: 'p_007',
        name: 'Ceramic Table Lamp',
        category: 'cat_home',
        brand: 'br_ikea',
        price: 89.99,
        originalPrice: 110.00,
        rating: 4.4,
        reviews: 34,
        isNew: false,
        stock: 40,
        description: 'A beautiful ceramic table lamp with a linen shade. Provides warm, ambient lighting perfect for bedrooms or living areas.',
        features: ['Hand-glazed ceramic', 'Linen shade', 'Dimmable switch', 'LED bulb included'],
        images: [
            'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&q=80'
        ],
        colors: ['#FFFFFF', '#D2B48C'],
        sizes: []
    },
    {
        id: 'p_008',
        name: 'Wireless Gaming Mouse',
        category: 'cat_electronics',
        brand: 'br_sony',
        price: 79.99,
        originalPrice: null,
        rating: 4.8,
        reviews: 215,
        isNew: true,
        stock: 150,
        description: 'Pro-grade wireless gaming mouse with an ultra-fast sensor, customizable RGB lighting, and up to 70 hours of battery life.',
        features: ['20K DPI Sensor', 'Optical switches', 'RGB Lighting', '70h battery'],
        images: [
            'https://images.unsplash.com/photo-1527814050087-37938154798c?w=800&q=80'
        ],
        colors: ['#000000', '#FFFFFF'],
        sizes: []
    }
];

window.mockData = {
    categories: mockCategories,
    brands: mockBrands,
    products: mockProducts
};
