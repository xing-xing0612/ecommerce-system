// Main SPA App Logic & Routing

class App {
    constructor() {
        this.root = document.getElementById('app-root');
        this.currentRoute = '';
        this.routes = {
            'home': () => window.Pages.renderHome(),
            'products': () => window.Pages.renderProducts(),
            'product': (params) => window.Pages.renderProductDetail(params.id),
            'checkout': () => window.Pages.renderCheckout(),
            'user': () => window.Pages.renderUserDashboard(),
            'admin': () => window.Admin.renderDashboard()
        };

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateNavUI();
        this.renderCartSidebar();
        
        // Initial Route
        const hash = window.location.hash.slice(1) || 'home';
        const [route, paramsStr] = hash.split('?');
        const params = paramsStr ? Object.fromEntries(new URLSearchParams(paramsStr)) : {};
        
        this.navigate(route || 'home', params, false);

        // Listen for store events
        utils.events.on('cartUpdated', () => this.renderCartSidebar());
        utils.events.on('userUpdated', () => this.updateNavUI());
        utils.events.on('themeChanged', () => this.updateThemeIcon());
        
        if (window.Pages && window.Pages.initFooterLinks) {
            window.Pages.initFooterLinks();
        }
    }

    setupEventListeners() {
        // Global Navigation Clicks
        document.addEventListener('click', (e) => {
            const link = e.target.closest('[data-route]');
            if (link) {
                e.preventDefault();
                const route = link.dataset.route;
                this.navigate(route);
                
                // Close mobile menu if open
                document.getElementById('mobileMenu').classList.add('hidden');
            }

            // Add to Cart global handler
            const addToCartBtn = e.target.closest('.add-to-cart-btn');
            if (addToCartBtn) {
                const id = addToCartBtn.dataset.id;
                const product = utils.getById(store.products, id);
                if (product) {
                    store.addToCart(product, 1);
                    UI.toast(`Added ${product.name} to cart`, 'success');
                    this.toggleCart(true);
                }
            }
        });

        // Browser Back/Forward
        window.addEventListener('hashchange', () => {
            const hash = window.location.hash.slice(1);
            if (!hash) return;
            const [route, paramsStr] = hash.split('?');
            const params = paramsStr ? Object.fromEntries(new URLSearchParams(paramsStr)) : {};
            if(this.currentRoute !== route) {
                this.navigate(route, params, false);
            }
        });

        // Theme Toggle
        document.getElementById('themeToggle').addEventListener('click', () => store.toggleTheme());
        document.getElementById('mobileThemeToggle').addEventListener('click', (e) => {
            e.preventDefault();
            store.toggleTheme();
        });

        // Cart Sidebar Toggles
        document.getElementById('cartBtn').addEventListener('click', () => this.toggleCart());
        document.getElementById('mobileCartBtn').addEventListener('click', (e) => {
            e.preventDefault();
            this.toggleCart();
        });
        document.getElementById('closeCartBtn').addEventListener('click', () => this.toggleCart(false));
        document.getElementById('sidebarOverlay').addEventListener('click', () => this.toggleCart(false));

        // Mobile Menu Toggle
        document.getElementById('mobileMenuBtn').addEventListener('click', () => {
            document.getElementById('mobileMenu').classList.toggle('hidden');
        });

        // User Icon Click
        document.getElementById('userBtn').addEventListener('click', () => this.handleUserAction());
        document.getElementById('mobileUserBtn').addEventListener('click', (e) => {
            e.preventDefault();
            this.handleUserAction();
        });
        
        // Setup initial theme icon
        this.updateThemeIcon();
    }

    navigate(route, params = {}, updateHash = true) {
        if (!this.routes[route]) {
            route = 'home';
        }

        // Auth Guards
        if (route === 'user' && !store.user) {
            UI.showAuthModal();
            return;
        }
        if (route === 'admin' && (!store.user || store.user.role !== 'admin')) {
            UI.toast('Unauthorized access', 'error');
            this.navigate('home');
            return;
        }

        this.currentRoute = route;
        
        // Update hash
        if (updateHash) {
            let hashStr = `#${route}`;
            if (Object.keys(params).length > 0) {
                hashStr += `?${new URLSearchParams(params).toString()}`;
            }
            window.location.hash = hashStr;
        }

        // Animate out current content
        this.root.classList.add('page-exit');
        
        setTimeout(async () => {
            // Render new content
            try {
                const content = await this.routes[route](params);
                this.root.innerHTML = content || '';
                
                // Execute page specific scripts if any
                if(window.Pages && typeof window.Pages[`init${route.charAt(0).toUpperCase() + route.slice(1)}`] === 'function') {
                    window.Pages[`init${route.charAt(0).toUpperCase() + route.slice(1)}`]();
                }
            } catch (e) {
                console.error("ROUTING/INIT ERROR:", e);
                this.root.innerHTML = `<div style="padding: 2rem; color: white; background: red;"><h2>Error rendering ${route}</h2><pre>${e.stack}</pre></div>`;
            }

            window.scrollTo(0, 0);

            // Animate in
            this.root.classList.remove('page-exit');
            this.root.classList.add('page-enter');
            
            setTimeout(() => {
                this.root.classList.remove('page-enter');
            }, 400);

            this.updateNavActiveState(route);
        }, 300); // Wait for exit animation
    }

    updateNavActiveState(route) {
        document.querySelectorAll('.nav-links a[data-route]').forEach(link => {
            if (link.dataset.route === route) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    updateNavUI() {
        const userBtn = document.getElementById('userBtn');
        const mobileUserBtn = document.getElementById('mobileUserBtn');
        
        if (store.user) {
            if (store.user.avatar) {
                userBtn.innerHTML = `<img src="${store.user.avatar}" style="width:24px; height:24px; border-radius:50%; object-fit:cover; border: 1px solid var(--primary); display:block; margin: 0 auto;">`;
            } else {
                userBtn.innerHTML = `<i class="fa-solid fa-user-circle" style="color: var(--primary)"></i>`;
            }
            mobileUserBtn.textContent = `Hi, ${store.user.name}`;
        } else {
            userBtn.innerHTML = `<i class="fa-solid fa-user"></i>`;
            mobileUserBtn.textContent = `Account`;
        }
    }

    updateThemeIcon() {
        const icon = document.querySelector('#themeToggle i');
        if (store.theme === 'dark') {
            icon.className = 'fa-solid fa-sun';
        } else {
            icon.className = 'fa-solid fa-moon';
        }
    }

    handleUserAction() {
        if (store.user) {
            if (store.user.role === 'admin') {
                this.navigate('admin');
            } else {
                this.navigate('user');
            }
        } else {
            UI.showAuthModal();
        }
        document.getElementById('mobileMenu').classList.add('hidden');
    }

    toggleCart(forceState) {
        const sidebar = document.getElementById('cart-sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        const isActive = forceState !== undefined ? forceState : !sidebar.classList.contains('active');
        
        if (isActive) {
            sidebar.classList.add('active');
            overlay.classList.add('active');
            document.getElementById('mobileMenu').classList.add('hidden');
        } else {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        }
    }

    renderCartSidebar() {
        const cartCount = store.getCartCount();
        document.getElementById('cartCount').textContent = cartCount;
        document.getElementById('mobileCartCount').textContent = cartCount;
        
        document.getElementById('cartTotalPrice').textContent = utils.formatPrice(store.getCartTotal());
        
        const container = document.getElementById('cartItems');
        const btn = document.getElementById('checkoutBtn');

        if (store.cart.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding: 3rem 1rem; color: var(--text-secondary)">
                    <i class="fa-solid fa-shopping-cart" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <p>Your cart is empty.</p>
                </div>
            `;
            btn.disabled = true;
            return;
        }

        btn.disabled = false;
        container.innerHTML = store.cart.map(item => `
            <div class="cart-item">
                <img src="${item.product.images[0]}" alt="${item.product.name}" class="cart-item-img">
                <div class="cart-item-details">
                    <div class="cart-item-title">${item.product.name}</div>
                    ${item.options.color ? `<div style="font-size: 0.8rem; color: var(--text-secondary)">Color: <span style="display:inline-block;width:10px;height:10px;background:${item.options.color};border-radius:50%;border:1px solid #ccc"></span></div>` : ''}
                    ${item.options.size ? `<div style="font-size: 0.8rem; color: var(--text-secondary)">Size: ${item.options.size}</div>` : ''}
                    
                    <div class="cart-item-price">${utils.formatPrice(item.product.price)}</div>
                    
                    <div class="cart-item-actions" style="margin-top: 0.5rem">
                        <div class="quantity-control">
                            <button class="qty-btn" onclick="if(${item.quantity - 1} < 1) { UI.confirm('Remove this item from your cart?', () => { store.removeFromCart('${item.id}'); UI.toast('Item removed from cart', 'info'); }); } else { store.updateCartQuantity('${item.id}', ${item.quantity - 1}); }">-</button>
                            <input type="text" class="qty-input" value="${item.quantity}" readonly>
                            <button class="qty-btn" onclick="store.updateCartQuantity('${item.id}', ${item.quantity + 1})">+</button>
                            <button class="btn btn-ghost remove-btn" onclick="UI.confirm('Remove this item from your cart?', () => { store.removeFromCart('${item.id}'); UI.toast('Item removed from cart', 'info'); })">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Remove global chat widget since it is now in dashboards
}

// Ensure init after everything is loaded
window.addEventListener('DOMContentLoaded', () => {
    window.Pages = window.Pages || {};
    window.Admin = window.Admin || {};
    
    // Initialize application
    window.app = new App();
});
