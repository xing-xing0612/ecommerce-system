// Pages Renderers and Logic

window.Pages = {
    // --- Home Page ---
    async renderHome() {
        const products = store.products;
        const featuredProducts = products.slice(0, 4);
        const newArrivals = products.filter(p => p.isNew).slice(0, 4);
        
        return `
            <section class="hero-section">
                <div class="hero-bg">
                    <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80" alt="Hero Background">
                </div>
                <div class="container">
                    <div class="hero-content">
                        <h1>Redefine Your Lifestyle with Aura.</h1>
                        <p>Discover our curated collection of premium electronics, fashion, and home goods designed for the modern individual.</p>
                        <button class="btn btn-primary" style="font-size: 1.1rem; padding: 1rem 2rem;" data-route="products">
                            Shop Now <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </section>

            <section class="container" style="padding-top: 4rem;">
                <h2 class="section-title">Shop by Category</h2>
                <div class="categories-grid">
                    ${window.mockData.categories.map(cat => `
                        <div class="category-card hover-scale" onclick="app.navigate('products', {category: '${cat.id}'})">
                            <img src="${cat.image}" alt="${cat.name}" loading="lazy">
                            <h3>${cat.name}</h3>
                        </div>
                    `).join('')}
                </div>
            </section>

            <section class="container" style="padding-top: 4rem;">
                <h2 class="section-title">Featured Products</h2>
                <div class="products-grid">
                    ${featuredProducts.map(p => UI.renderProductCard(p)).join('')}
                </div>
            </section>
            
            <section class="container" style="padding-top: 2rem;">
                <h2 class="section-title">New Arrivals</h2>
                <div class="products-grid">
                    ${newArrivals.map(p => UI.renderProductCard(p)).join('')}
                </div>
            </section>
            
            <section class="container" style="padding-top: 4rem; padding-bottom: 2rem;">
                <div class="card" style="display: flex; flex-wrap: wrap; gap: 2rem; align-items: center; background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%); color: white; border: none;">
                    <div style="flex: 1; min-width: 300px;">
                        <h2 style="margin-bottom: 1rem;">Summer Sale is Live!</h2>
                        <p style="font-size: 1.2rem; opacity: 0.9; margin-bottom: 2rem;">Get up to 50% off on selected items. Free shipping on orders over $100.</p>
                        <button class="btn btn-outline" style="color: white; border-color: white;" data-route="products">Explore Sale</button>
                    </div>
                    <div style="flex: 1; min-width: 300px; display: flex; gap: 1rem; justify-content: center;">
                        <div style="text-align: center; background: rgba(0,0,0,0.2); padding: 1rem; border-radius: var(--radius-md); min-width: 80px;">
                            <div style="font-size: 2rem; font-weight: bold;">02</div>
                            <div style="font-size: 0.8rem; text-transform: uppercase;">Days</div>
                        </div>
                        <div style="text-align: center; background: rgba(0,0,0,0.2); padding: 1rem; border-radius: var(--radius-md); min-width: 80px;">
                            <div style="font-size: 2rem; font-weight: bold;">14</div>
                            <div style="font-size: 0.8rem; text-transform: uppercase;">Hours</div>
                        </div>
                        <div style="text-align: center; background: rgba(0,0,0,0.2); padding: 1rem; border-radius: var(--radius-md); min-width: 80px;">
                            <div style="font-size: 2rem; font-weight: bold;">45</div>
                            <div style="font-size: 0.8rem; text-transform: uppercase;">Mins</div>
                        </div>
                    </div>
                </div>
            </section>
        `;
    },

    // --- Products Listing Page ---
    async renderProducts(params = {}) {
        const categoryFilter = params.category || 'all';
        let products = [...store.products];
        
        if (categoryFilter !== 'all') {
            products = products.filter(p => p.category === categoryFilter);
        }

        return `
            <div class="container products-page">
                <aside class="products-sidebar card">
                    <h3 style="margin-bottom: 1.5rem;">Filters</h3>
                    
                    <div style="margin-bottom: 2rem;">
                        <h4 style="margin-bottom: 1rem; font-size: 1rem;">Categories</h4>
                        <ul style="display: flex; flex-direction: column; gap: 0.5rem;">
                            <li>
                                <a href="#" data-route="products" class="${categoryFilter === 'all' ? 'text-gradient' : ''}">All Products</a>
                            </li>
                            ${window.mockData.categories.map(cat => `
                                <li>
                                    <a href="#" data-route="products" data-params="category=${cat.id}" class="${categoryFilter === cat.id ? 'text-gradient' : ''}">${cat.name}</a>
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                    
                    <div style="margin-bottom: 2rem;">
                        <h4 style="margin-bottom: 1rem; font-size: 1rem;">Price Range</h4>
                        <input type="range" style="width: 100%;" min="0" max="1000">
                        <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; font-size: 0.875rem; color: var(--text-secondary);">
                            <span>$0</span>
                            <span>$1000+</span>
                        </div>
                    </div>
                </aside>
                
                <main class="products-main">
                    <div class="products-header">
                        <h2>${categoryFilter === 'all' ? 'All Products' : window.mockData.categories.find(c => c.id === categoryFilter)?.name} <span style="color: var(--text-secondary); font-size: 1rem; font-weight: normal;">(${products.length} items)</span></h2>
                        <select class="form-control" style="width: auto;">
                            <option>Sort by: Featured</option>
                            <option>Price: Low to High</option>
                            <option>Price: High to Low</option>
                            <option>Newest Arrivals</option>
                        </select>
                    </div>
                    
                    <div class="products-grid" style="padding-top: 0;">
                        ${products.map(p => UI.renderProductCard(p)).join('')}
                    </div>
                </main>
            </div>
        `;
    },

    // --- Product Detail Page ---
    async renderProductDetail(id) {
        const product = utils.getById(store.products, id);
        if (!product) return `<div class="container" style="padding: 4rem 0; text-align: center;"><h2>Product not found</h2></div>`;
        
        const hasDiscount = product.originalPrice && product.originalPrice > product.price;

        return `
            <div class="container product-detail" id="product-${product.id}">
                <div class="product-gallery">
                    <img src="${product.images[0]}" alt="${product.name}" class="main-image" id="mainImage">
                    <div class="thumbnail-list">
                        ${product.images.map((img, idx) => `
                            <img src="${img}" class="thumbnail ${idx === 0 ? 'active' : ''}" onclick="window.Pages.setMainImage('${img}', this)">
                        `).join('')}
                    </div>
                </div>
                
                <div class="product-info-detail">
                    <div style="color: var(--primary); font-weight: 600; margin-bottom: 0.5rem; text-transform: uppercase; font-size: 0.875rem;">
                        ${window.mockData.brands.find(b => b.id === product.brand)?.name || ''}
                    </div>
                    <h1>${product.name}</h1>
                    
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem;">
                        <div style="color: var(--warning);">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star-half-stroke"></i>
                        </div>
                        <span style="color: var(--text-secondary)">${product.rating} (${product.reviews} reviews)</span>
                    </div>
                    
                    <div style="font-size: 2rem; font-weight: 700; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 1rem;">
                        <span class="${hasDiscount ? 'text-gradient' : ''}">${utils.formatPrice(product.price)}</span>
                        ${hasDiscount ? `<span style="text-decoration: line-through; color: var(--text-secondary); font-size: 1.25rem; font-weight: normal;">${utils.formatPrice(product.originalPrice)}</span>` : ''}
                        ${hasDiscount ? `<span class="badge badge-danger">Save ${utils.calculateDiscount(product.price, product.originalPrice)}%</span>` : ''}
                    </div>
                    
                    <p style="font-size: 1.1rem; color: var(--text-secondary); margin-bottom: 2rem;">${product.description}</p>
                    
                    <div class="sku-selector">
                        ${product.colors && product.colors.length > 0 ? `
                            <div style="margin-bottom: 1.5rem;">
                                <h4>Color</h4>
                                <div class="color-options">
                                    ${product.colors.map((color, idx) => `
                                        <button class="color-btn ${idx === 0 ? 'active' : ''}" style="background-color: ${color};" data-color="${color}"></button>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                        
                        ${product.sizes && product.sizes.length > 0 ? `
                            <div style="margin-bottom: 1.5rem;">
                                <h4>Size</h4>
                                <div class="size-options">
                                    ${product.sizes.map((size, idx) => `
                                        <button class="size-btn ${idx === 0 ? 'active' : ''}" data-size="${size}">${size}</button>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="add-to-cart-section">
                        <div class="quantity-control" style="padding: 0.5rem;">
                            <button class="qty-btn" id="pd-qty-minus">-</button>
                            <input type="text" class="qty-input" id="pd-qty" value="1" readonly style="width: 50px;">
                            <button class="qty-btn" id="pd-qty-plus">+</button>
                        </div>
                        <button class="btn btn-primary" id="pd-add-to-cart" style="flex: 1; font-size: 1.1rem;">
                            <i class="fa-solid fa-cart-plus"></i> Add to Cart
                        </button>
                        <button class="btn btn-outline btn-icon" style="width: 50px; height: 50px;" title="Toggle Wishlist" onclick="if(!store.user){ UI.showAuthModal(); return; } store.toggleWishlist('${product.id}'); const i = this.querySelector('i'); if(i.classList.contains('fa-solid')){ i.classList.replace('fa-solid', 'fa-regular'); i.style.color=''; UI.toast('Removed from wishlist', 'info'); } else { i.classList.replace('fa-regular', 'fa-solid'); i.style.color='var(--danger)'; UI.toast('Added to wishlist', 'success'); }">
                            <i class="${store.user && store.user.wishlist && store.user.wishlist.includes(product.id) ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}" style="${store.user && store.user.wishlist && store.user.wishlist.includes(product.id) ? 'color: var(--danger);' : ''} transition: color 0.3s ease;"></i>
                        </button>
                    </div>
                    
                    <div style="margin-top: 3rem; border-top: 1px solid var(--border-color); padding-top: 2rem;">
                        <h4 style="margin-bottom: 1rem;">Features</h4>
                        <ul style="list-style-type: disc; padding-left: 1.5rem; color: var(--text-secondary);">
                            ${product.features.map(f => `<li style="margin-bottom: 0.5rem;">${f}</li>`).join('')}
                        </ul>
                    </div>
                </div>
            </div>
        `;
    },

    initProduct() {
        // Thumbnail switching
        window.Pages.setMainImage = (src, el) => {
            document.getElementById('mainImage').src = src;
            document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
            el.classList.add('active');
        };

        // SKU selection
        document.querySelectorAll('.color-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        // Quantity
        const qtyInput = document.getElementById('pd-qty');
        if(!qtyInput) return;
        
        document.getElementById('pd-qty-minus').addEventListener('click', () => {
            let val = parseInt(qtyInput.value);
            if (val > 1) qtyInput.value = val - 1;
        });
        document.getElementById('pd-qty-plus').addEventListener('click', () => {
            qtyInput.value = parseInt(qtyInput.value) + 1;
        });

        // Add to cart logic
        document.getElementById('pd-add-to-cart').addEventListener('click', () => {
            const container = document.querySelector('.product-detail');
            const productId = container.id.replace('product-', '');
            const product = utils.getById(store.products, productId);
            
            const qty = parseInt(qtyInput.value);
            const activeColorBtn = document.querySelector('.color-btn.active');
            const activeSizeBtn = document.querySelector('.size-btn.active');
            
            const options = {
                color: activeColorBtn ? activeColorBtn.dataset.color : null,
                size: activeSizeBtn ? activeSizeBtn.dataset.size : null
            };

            store.addToCart(product, qty, options);
            UI.toast(`Added ${product.name} to cart`, 'success');
            app.toggleCart(true);
        });
    },

    // --- Checkout Page ---
    async renderCheckout() {
        if (store.cart.length === 0) {
            return `
                <div class="container" style="padding: 4rem 0; text-align: center;">
                    <h2>Your cart is empty</h2>
                    <p style="margin: 1rem 0 2rem;">Add some products to your cart to proceed with checkout.</p>
                    <button class="btn btn-primary" data-route="products">Go Shopping</button>
                </div>
            `;
        }

        return `
            <div class="container checkout-container">
                <div class="checkout-main">
                    <div class="checkout-steps">
                        <div class="checkout-step active" id="step1-indicator">1. Shipping</div>
                        <div class="checkout-step" id="step2-indicator">2. Payment</div>
                        <div class="checkout-step" id="step3-indicator">3. Confirmation</div>
                    </div>
                    
                    <div class="card" id="checkout-step-1">
                        <h3 style="margin-bottom: 1.5rem;">Shipping Information</h3>
                        <form id="shipping-form" onsubmit="event.preventDefault(); window.Pages.nextCheckoutStep(2);">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control" required value="${store.user ? store.user.name : ''}">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Address</label>
                                <input type="text" class="form-control" required placeholder="123 Main St">
                            </div>
                            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">City</label>
                                    <input type="text" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">State</label>
                                    <input type="text" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">ZIP</label>
                                    <input type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Shipping Method</label>
                                <select class="form-control">
                                    <option>Standard Shipping (3-5 days) - Free</option>
                                    <option>Express Shipping (1-2 days) - $15.00</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-full" style="margin-top: 1rem;">Continue to Payment</button>
                        </form>
                    </div>
                    
                    <div class="card hidden" id="checkout-step-2">
                        <h3 style="margin-bottom: 1.5rem;">Payment Method</h3>
                        <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
                            <div class="card cursor-pointer payment-method active" data-method="credit" style="flex:1; text-align: center; border-color: var(--primary);" onclick="window.Pages.selectPayment('credit', this)">
                                <i class="fa-regular fa-credit-card" style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--primary)"></i>
                                <div>Credit Card</div>
                            </div>
                            <div class="card cursor-pointer payment-method" data-method="paypal" style="flex:1; text-align: center;" onclick="window.Pages.selectPayment('paypal', this)">
                                <i class="fa-brands fa-paypal" style="font-size: 2rem; margin-bottom: 0.5rem;"></i>
                                <div>PayPal</div>
                            </div>
                        </div>
                        
                        <form id="payment-form" onsubmit="event.preventDefault(); window.Pages.processOrder();">
                            <div id="credit-info">
                                <div class="form-group">
                                    <label class="form-label">Card Number</label>
                                    <input type="text" class="form-control" placeholder="0000 0000 0000 0000" id="cc-number" required>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                    <div class="form-group">
                                        <label class="form-label">Expiry Date</label>
                                        <input type="text" class="form-control" placeholder="MM/YY" id="cc-exp" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">CVC</label>
                                        <input type="text" class="form-control" placeholder="123" id="cc-cvc" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Name on Card</label>
                                    <input type="text" class="form-control" id="cc-name" required>
                                </div>
                            </div>
                            
                            <div id="paypal-info" class="hidden" style="text-align: center; padding: 2rem 0;">
                                <i class="fa-brands fa-paypal" style="font-size: 3rem; color: #003087; margin-bottom: 1rem;"></i>
                                <p style="color: var(--text-secondary); margin-bottom: 1rem;">You will be redirected to PayPal to complete your purchase securely.</p>
                            </div>
                            
                            <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                                <button type="button" class="btn btn-outline" onclick="window.Pages.nextCheckoutStep(1);" style="flex: 1;">Back</button>
                                <button type="submit" class="btn btn-primary" id="place-order-btn" style="flex: 2;">Place Order</button>
                            </div>
                        </form>
                    </div>
                    
                    <div class="card hidden" id="checkout-step-3" style="text-align: center; padding: 4rem 2rem;">
                        <div style="width: 80px; height: 80px; background: var(--success); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2.5rem; margin: 0 auto 2rem;">
                            <i class="fa-solid fa-check"></i>
                        </div>
                        <h2 style="margin-bottom: 1rem;">Order Confirmed!</h2>
                        <p style="color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem;">Thank you for your purchase. Your order <strong id="confirm-order-id">#12345</strong> is being processed.</p>
                        <button class="btn btn-primary" data-route="products">Continue Shopping</button>
                    </div>
                </div>
                
                <aside class="checkout-sidebar">
                    <div class="card">
                        <h3 style="margin-bottom: 1.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">Order Summary</h3>
                        <div style="max-height: 300px; overflow-y: auto; margin-bottom: 1.5rem;">
                            ${store.cart.map(item => `
                                <div style="display: flex; gap: 1rem; margin-bottom: 1rem;">
                                    <img src="${item.product.images[0]}" style="width: 60px; height: 60px; border-radius: var(--radius-sm); object-fit: cover;">
                                    <div style="flex: 1;">
                                        <div style="font-weight: 600; font-size: 0.9rem;">${item.product.name}</div>
                                        <div style="color: var(--text-secondary); font-size: 0.8rem;">Qty: ${item.quantity}</div>
                                    </div>
                                    <div style="font-weight: 600;">${utils.formatPrice(item.product.price * item.quantity)}</div>
                                </div>
                            `).join('')}
                        </div>
                        
                        <div style="border-top: 1px solid var(--border-color); padding-top: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem; color: var(--text-secondary);">
                                <span>Subtotal</span>
                                <span>${utils.formatPrice(store.getCartTotal())}</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem; color: var(--text-secondary);">
                                <span>Shipping</span>
                                <span>Free</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem; color: var(--text-secondary);">
                                <span>Tax (10%)</span>
                                <span>${utils.formatPrice(store.getCartTotal() * 0.1)}</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 1.25rem; font-weight: 700; border-top: 1px solid var(--border-color); padding-top: 1rem;">
                                <span>Total</span>
                                <span class="text-gradient">${utils.formatPrice(store.getCartTotal() * 1.1)}</span>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
        `;
    },

    initCheckout() {
        window.Pages.selectPayment = (method, el) => {
            document.querySelectorAll('.payment-method').forEach(b => {
                b.classList.remove('active');
                b.style.borderColor = 'var(--border-glass)';
                b.querySelector('i').style.color = 'inherit';
            });
            el.classList.add('active');
            el.style.borderColor = 'var(--primary)';
            el.querySelector('i').style.color = 'var(--primary)';
            
            if(method === 'paypal') {
                document.getElementById('credit-info').classList.add('hidden');
                document.getElementById('paypal-info').classList.remove('hidden');
                document.querySelectorAll('#credit-info input').forEach(inp => inp.removeAttribute('required'));
            } else {
                document.getElementById('paypal-info').classList.add('hidden');
                document.getElementById('credit-info').classList.remove('hidden');
                document.querySelectorAll('#credit-info input').forEach(inp => inp.setAttribute('required', 'true'));
            }
        };

        window.Pages.nextCheckoutStep = (step) => {
            document.querySelectorAll('[id^="checkout-step-"]').forEach(el => el.classList.add('hidden'));
            document.getElementById(`checkout-step-${step}`).classList.remove('hidden');
            
            // Update indicators
            document.querySelectorAll('.checkout-step').forEach((el, idx) => {
                el.classList.remove('active', 'completed');
                if (idx + 1 < step) el.classList.add('completed');
                if (idx + 1 === step) el.classList.add('active');
            });
            window.scrollTo(0, 0);
        };

        window.Pages.processOrder = () => {
            const btn = document.getElementById('place-order-btn');
            btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;border-top-color:white;"></div> Processing...';
            btn.disabled = true;
            
            setTimeout(() => {
                const order = store.createOrder({method: 'Standard', address: '123 Main St'}, {method: 'Credit Card'});
                document.getElementById('confirm-order-id').textContent = '#' + order.id;
                window.Pages.nextCheckoutStep(3);
                
                // Hide sidebar summary on completion
                const sidebar = document.querySelector('.checkout-sidebar');
                if(sidebar) sidebar.style.display = 'none';
                
                document.querySelector('.checkout-main').style.gridColumn = '1 / -1';
            }, 1500);
        };
    },

    // --- User Dashboard Page ---
    async renderUserDashboard() {
        if (!store.user) return '';

        return `
            <div class="container" style="padding: 4rem 0;">
                <div class="card" style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, var(--bg-card) 0%, var(--bg-primary) 100%);">
                    <div style="display: flex; align-items: center; gap: 1.5rem;">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: var(--bg-secondary); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 2.5rem; font-weight: bold; overflow: hidden; border: 2px solid var(--border-color);">
                            ${store.user.avatar ? `<img src="${store.user.avatar}" style="width:100%; height:100%; object-fit:cover;">` : store.user.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <h2 style="margin: 0;">${store.user.name}</h2>
                            <p style="color: var(--text-secondary); margin: 0;">${store.user.email}</p>
                            ${store.user.role === 'admin' ? '<span class="badge badge-primary" style="margin-top: 0.5rem;">Administrator</span>' : ''}
                        </div>
                    </div>
                    <button class="btn btn-outline" onclick="store.logout(); app.navigate('home');">
                        <i class="fa-solid fa-sign-out-alt"></i> Logout
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 280px 1fr; gap: 2rem;">
                    <aside>
                        <div class="card" style="padding: 0; overflow: hidden; position: sticky; top: 100px;">
                            <ul style="display: flex; flex-direction: column;">
                                <li><button class="btn btn-ghost btn-full active user-tab" onclick="window.Pages.switchUserTab('user-orders-view', this)" style="justify-content: flex-start; border-radius: 0; padding: 1rem 1.5rem; background: var(--bg-primary); color: var(--primary); border-left: 3px solid var(--primary);"><i class="fa-solid fa-box" style="width: 24px;"></i> Order History</button></li>
                                <li><button class="btn btn-ghost btn-full user-tab" onclick="window.Pages.switchUserTab('user-addresses-view', this)" style="justify-content: flex-start; border-radius: 0; padding: 1rem 1.5rem; border-left: 3px solid transparent;"><i class="fa-solid fa-map-marker-alt" style="width: 24px;"></i> Addresses</button></li>
                                <li><button class="btn btn-ghost btn-full user-tab" onclick="window.Pages.switchUserTab('user-wishlist-view', this)" style="justify-content: flex-start; border-radius: 0; padding: 1rem 1.5rem; border-left: 3px solid transparent;"><i class="fa-regular fa-heart" style="width: 24px;"></i> Wishlist</button></li>
                                <li><button class="btn btn-ghost btn-full user-tab" onclick="window.Pages.switchUserTab('user-support-view', this)" style="justify-content: flex-start; border-radius: 0; padding: 1rem 1.5rem; border-left: 3px solid transparent;"><i class="fa-solid fa-headset" style="width: 24px;"></i> Support</button></li>
                                <li><button class="btn btn-ghost btn-full user-tab" onclick="window.Pages.switchUserTab('user-settings-view', this)" style="justify-content: flex-start; border-radius: 0; padding: 1rem 1.5rem; border-left: 3px solid transparent;"><i class="fa-solid fa-cog" style="width: 24px;"></i> Settings</button></li>
                            </ul>
                        </div>
                    </aside>
                    
                    <main>
                        <!-- Orders View -->
                        <div class="card user-view" id="user-orders-view">
                            <h3 style="margin-bottom: 1.5rem;">Recent Orders</h3>
                            ${store.orders.length === 0 ? `
                                <div style="text-align: center; padding: 3rem 0; color: var(--text-secondary);">
                                    <i class="fa-solid fa-box-open" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                                    <p>You haven't placed any orders yet.</p>
                                    <button class="btn btn-primary" style="margin-top: 1rem;" data-route="products">Start Shopping</button>
                                </div>
                            ` : `
                                <div style="overflow-x: auto;">
                                    <table style="width: 100%; border-collapse: collapse; text-align: left; white-space: nowrap;">
                                        <thead>
                                            <tr style="border-bottom: 2px solid var(--border-color); color: var(--text-secondary);">
                                                <th style="padding: 1.2rem 1.5rem;">Order ID</th>
                                                <th style="padding: 1.2rem 1.5rem;">Date</th>
                                                <th style="padding: 1.2rem 1.5rem;">Status</th>
                                                <th style="padding: 1.2rem 1.5rem;">Total</th>
                                                <th style="padding: 1.2rem 1.5rem;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${[...store.orders].reverse().map(order => `
                                                <tr style="border-bottom: 1px solid var(--border-color);" class="hover-bg">
                                                    <td style="padding: 1.2rem 1.5rem; font-weight: 600;">${order.id}</td>
                                                    <td style="padding: 1.2rem 1.5rem; color: var(--text-secondary);">${new Date(order.date).toLocaleDateString()}</td>
                                                    <td style="padding: 1.2rem 1.5rem;"><span class="badge ${order.status === 'Processing' ? 'badge-warning' : (order.status === 'Shipped' ? 'badge-primary' : 'badge-success')}">${order.status}</span></td>
                                                    <td style="padding: 1.2rem 1.5rem; font-weight: 600;">${utils.formatPrice(order.total * 1.1)}</td>
                                                    <td style="padding: 1.2rem 1.5rem;"><button class="btn btn-ghost btn-icon" onclick="window.Pages.showOrderDetails('${order.id}')"><i class="fa-solid fa-chevron-right"></i></button></td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            `}
                        </div>

                        <!-- Addresses View -->
                        <div class="card user-view hidden" id="user-addresses-view">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                                <h3>Your Addresses</h3>
                            </div>
                            
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem;">
                                ${(store.user.addresses || []).map(addr => `
                                    <div class="card" style="border: 1px solid var(--border-color); box-shadow: none;">
                                        <div style="display:flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                            <h4 style="margin: 0;">${addr.title}</h4>
                                            <span class="badge badge-primary">Default</span>
                                        </div>
                                        <p style="color: var(--text-secondary); margin-bottom: 0.5rem; line-height: 1.5;">
                                            ${addr.street}<br>${addr.city}, ${addr.zip}<br>${addr.country}
                                        </p>
                                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                                            <button class="btn btn-ghost btn-icon" style="flex:1;" onclick="window.Pages.editAddress('${addr.id}')"><i class="fa-solid fa-edit"></i> Edit</button>
                                            <button class="btn btn-ghost btn-icon" style="flex:1; color: var(--danger);" onclick="window.Pages.deleteAddress('${addr.id}')"><i class="fa-solid fa-trash"></i></button>
                                        </div>
                                    </div>
                                `).join('')}
                                
                                <div class="card hover-lift" style="border: 1px dashed var(--border-color); box-shadow: none; display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; min-height: 150px;" onclick="document.getElementById('add-addr-form').classList.toggle('hidden');">
                                    <i class="fa-solid fa-plus" style="font-size: 2rem; color: var(--text-secondary); margin-bottom: 0.5rem;"></i>
                                    <span style="color: var(--text-secondary);">Add New Address</span>
                                </div>
                            </div>
                            
                            <form id="add-addr-form" class="hidden" style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color);" onsubmit="event.preventDefault(); window.Pages.saveAddress();">
                                <h4 id="addr-form-title">Add New Address</h4>
                                <input type="hidden" id="addr-id" value="">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                                    <div class="form-group"><label>Title (e.g. Home, Work)</label><input type="text" id="addr-title" class="form-control" required></div>
                                    <div class="form-group"><label>Street Address</label><input type="text" id="addr-street" class="form-control" required></div>
                                    <div class="form-group"><label>City</label><input type="text" id="addr-city" class="form-control" required></div>
                                    <div class="form-group"><label>Zip/Postal Code</label><input type="text" id="addr-zip" class="form-control" required></div>
                                    <div class="form-group"><label>Country</label><input type="text" id="addr-country" class="form-control" required></div>
                                </div>
                                <button type="submit" class="btn btn-primary" style="margin-top: 1rem;">Save Address</button>
                            </form>
                        </div>

                        <!-- Wishlist View -->
                        <div class="card user-view hidden" id="user-wishlist-view">
                            <h3 style="margin-bottom: 1.5rem;">Your Wishlist</h3>
                            ${(!store.user.wishlist || store.user.wishlist.length === 0) ? `
                                <div style="text-align: center; padding: 4rem 0;">
                                    <i class="fa-regular fa-heart" style="font-size: 4rem; color: var(--text-secondary); margin-bottom: 1rem; opacity: 0.5;"></i>
                                    <p style="color: var(--text-secondary); margin-bottom: 2rem;">Items you've liked will appear here.</p>
                                    <button class="btn btn-primary" data-route="products">Explore Products</button>
                                </div>
                            ` : `
                                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1.5rem;">
                                    ${store.user.wishlist.map(id => {
                                        const p = utils.getById(store.products, id);
                                        if(!p) return '';
                                        return `
                                            <div class="card hover-lift" style="padding: 1rem;">
                                                <img src="${p.images[0]}" style="width: 100%; height: 150px; object-fit: cover; border-radius: var(--radius-sm); margin-bottom: 1rem;">
                                                <div style="font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${p.name}</div>
                                                <div style="color: var(--primary); font-weight: bold; margin-bottom: 1rem;">${utils.formatPrice(p.price)}</div>
                                                <div style="display: flex; gap: 0.5rem;">
                                                    <button class="btn btn-primary" style="flex:1; padding: 0.5rem;" onclick="store.addToCart(utils.getById(store.products, '${p.id}'), 1)"><i class="fa-solid fa-cart-plus"></i></button>
                                                    <button class="btn btn-outline" style="padding: 0.5rem;" onclick="store.toggleWishlist('${p.id}'); app.navigate('user');"><i class="fa-solid fa-trash"></i></button>
                                                </div>
                                            </div>
                                        `;
                                    }).join('')}
                                </div>
                            `}
                        </div>

                        <!-- Support View -->
                        <div class="card user-view hidden" id="user-support-view" style="display: flex; flex-direction: column; height: 600px; padding: 0;">
                            <div style="padding: 1.5rem; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                                <h3 style="margin: 0;">Customer Support</h3>
                                <button class="btn btn-outline" style="color: var(--danger); border-color: var(--danger); padding: 0.5rem 1rem;" onclick="window.Pages.endUserChat()"><i class="fa-solid fa-stop-circle"></i> End Session</button>
                            </div>
                            <div id="user-support-messages" style="flex: 1; overflow-y: auto; padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem; background: var(--bg-primary);">
                                <!-- Messages injected here -->
                            </div>
                            <div style="padding: 1.5rem; border-top: 1px solid var(--border-color); background: var(--bg-secondary); border-radius: 0 0 var(--radius-md) var(--radius-md);">
                                <form onsubmit="event.preventDefault(); window.Pages.sendUserChatMessage();" style="display: flex; gap: 1rem;">
                                    <input type="text" id="user-support-input" class="form-control" placeholder="Type your message to Admin..." required style="flex: 1;">
                                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> Send</button>
                                </form>
                            </div>
                        </div>

                        <!-- Settings View -->
                        <div class="card user-view hidden" id="user-settings-view">
                            <h3 style="margin-bottom: 1.5rem;">Account Settings</h3>
                            <form id="user-profile-form" onsubmit="event.preventDefault(); window.Pages.saveProfile();">
                                <div style="display: flex; gap: 2rem; margin-bottom: 2rem; align-items: center;">
                                    <div style="width: 100px; height: 100px; border-radius: 50%; background: var(--bg-secondary); border: 2px solid var(--border-color); overflow: hidden; position: relative;">
                                        <img id="profile-avatar-preview" src="${store.user.avatar || 'https://via.placeholder.com/100'}" style="width:100%; height:100%; object-fit:cover; ${store.user.avatar ? '' : 'display:none;'}">
                                        ${!store.user.avatar ? `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:2.5rem;">${store.user.name.charAt(0).toUpperCase()}</div>` : ''}
                                    </div>
                                    <div>
                                        <label class="btn btn-outline" style="cursor: pointer;">
                                            <i class="fa-solid fa-camera"></i> Change Avatar
                                            <input type="file" id="profile-avatar-input" accept="image/*" class="hidden" onchange="window.Pages.handleAvatarUpload(this)">
                                        </label>
                                        <p style="color: var(--text-secondary); font-size: 0.8rem; margin-top: 0.5rem;">Recommended: Square image, max 2MB.</p>
                                    </div>
                                </div>
                                
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                    <div class="form-group">
                                        <label class="form-label">Full Name</label>
                                        <input type="text" id="profile-name" class="form-control" required value="${store.user.name}">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Email Address (Read Only)</label>
                                        <input type="email" class="form-control" value="${store.user.email}" readonly disabled>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Phone Number</label>
                                        <input type="tel" id="profile-phone" class="form-control" placeholder="+1 (555) 000-0000" value="${store.user.phone || ''}">
                                    </div>
                                </div>
                                
                                <h4 style="margin: 2rem 0 1rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color);">Change Password</h4>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                    <div class="form-group">
                                        <label class="form-label">New Password</label>
                                        <input type="password" id="profile-password" class="form-control" placeholder="Leave blank to keep current">
                                    </div>
                                </div>
                                
                                <div style="margin-top: 2rem;">
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </main>
                </div>
            </div>
        `;
    },
    
    initUser() {
        window.Pages.switchUserTab = (targetId, el) => {
            document.querySelectorAll('.user-view').forEach(view => {
                view.classList.add('hidden');
            });
            document.getElementById(targetId).classList.remove('hidden');
            
            document.querySelectorAll('.user-tab').forEach(tab => {
                tab.classList.remove('active');
                tab.style.background = 'transparent';
                tab.style.color = 'inherit';
                tab.style.borderLeftColor = 'transparent';
            });
            
            el.classList.add('active');
            el.style.background = 'var(--bg-primary)';
            el.style.color = 'var(--primary)';
            el.style.borderLeftColor = 'var(--primary)';
        };
        
        // Support Chat logic
        window.Pages.renderUserChat = () => {
            if (!store.user) return;
            const chat = store.getChat(store.user.id, false);
            const container = document.getElementById('user-support-messages');
            if (!container) return;
            
            if (!chat || chat.messages.length === 0) {
                container.innerHTML = `
                    <div style="text-align: center; color: var(--text-secondary); margin-top: 2rem;">
                        <i class="fa-solid fa-headset" style="font-size: 3rem; opacity: 0.5; margin-bottom: 1rem;"></i>
                        <p>Welcome to Aura Support. Send a message to start chatting with an administrator.</p>
                    </div>
                `;
            } else {
                container.innerHTML = chat.messages.map(msg => {
                    const isUser = msg.sender === 'user';
                    return `
                        <div style="display: flex; gap: 0.75rem; max-width: 80%; ${isUser ? 'align-self: flex-end; flex-direction: row-reverse;' : 'align-self: flex-start;'}">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: ${isUser ? 'var(--text-secondary)' : 'var(--primary)'}; color: white; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; flex-shrink: 0;">
                                <i class="fa-solid ${isUser ? 'fa-user' : 'fa-robot'}"></i>
                            </div>
                            <div style="background: ${isUser ? 'var(--primary)' : 'var(--bg-secondary)'}; color: ${isUser ? 'white' : 'var(--text-primary)'}; padding: 0.75rem 1rem; border-radius: ${isUser ? 'var(--radius-md) 0 var(--radius-md) var(--radius-md)' : '0 var(--radius-md) var(--radius-md) var(--radius-md)'}; box-shadow: var(--shadow-sm);">
                                <div style="font-size: 0.95rem; line-height: 1.4;">${msg.text}</div>
                                <div style="font-size: 0.7rem; color: ${isUser ? 'rgba(255,255,255,0.7)' : 'var(--text-secondary)'}; margin-top: 0.25rem; text-align: ${isUser ? 'right' : 'left'};">
                                    ${new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            }
            container.scrollTop = container.scrollHeight;
        };
        
        window.Pages.sendUserChatMessage = () => {
            const input = document.getElementById('user-support-input');
            const text = input.value.trim();
            if (text && store.user) {
                store.sendMessage(store.user.id, text, 'user');
                input.value = '';
            }
        };
        
        window.Pages.endUserChat = () => {
            if (store.user) {
                UI.confirm('Are you sure you want to end this session?', () => {
                    store.endChat(store.user.id);
                    UI.toast('Chat session ended.', 'info');
                    window.Pages.renderUserChat();
                });
            }
        };

        window.Pages.renderUserChat();
        utils.events.on('chatUpdated', () => {
            if(document.getElementById('user-support-messages')) window.Pages.renderUserChat();
        });
        
        // Settings / Profile logic
        window.Pages.avatarBase64 = store.user.avatar || '';
        
        window.Pages.handleAvatarUpload = async (input) => {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    window.Pages.avatarBase64 = e.target.result;
                    const preview = document.getElementById('profile-avatar-preview');
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    if (preview.nextElementSibling) {
                        preview.nextElementSibling.style.display = 'none'; // hide the letter placeholder
                    }
                };
                reader.readAsDataURL(input.files[0]);
            }
        };
        
        window.Pages.saveProfile = () => {
            const name = document.getElementById('profile-name').value;
            const phone = document.getElementById('profile-phone').value;
            const pwd = document.getElementById('profile-password').value;
            
            const updates = {
                name,
                phone,
                avatar: window.Pages.avatarBase64
            };
            if(pwd && pwd.length >= 6) {
                updates.password = pwd;
            }
            
            store.updateUserProfile(updates);
            UI.toast('Profile updated successfully', 'success');
            
            // Re-render
            app.navigate('user');
        };
        
        window.Pages.saveAddress = () => {
            const id = document.getElementById('addr-id').value;
            const addr = {
                title: document.getElementById('addr-title').value,
                street: document.getElementById('addr-street').value,
                city: document.getElementById('addr-city').value,
                zip: document.getElementById('addr-zip').value,
                country: document.getElementById('addr-country').value,
            };
            if(id) {
                store.updateAddress(id, addr);
                UI.toast('Address updated', 'success');
            } else {
                store.addAddress(addr);
                UI.toast('Address added', 'success');
            }
            app.navigate('user');
        };
        
        window.Pages.editAddress = (id) => {
            const addr = store.user.addresses.find(a => a.id === id);
            if(!addr) return;
            document.getElementById('addr-id').value = id;
            document.getElementById('addr-title').value = addr.title;
            document.getElementById('addr-street').value = addr.street;
            document.getElementById('addr-city').value = addr.city;
            document.getElementById('addr-zip').value = addr.zip;
            document.getElementById('addr-country').value = addr.country;
            document.getElementById('addr-form-title').innerText = 'Edit Address';
            document.getElementById('add-addr-form').classList.remove('hidden');
        };
        
        window.Pages.deleteAddress = (id) => {
            UI.confirm("Are you sure you want to delete this address?", () => {
                store.deleteAddress(id);
                UI.toast('Address deleted', 'success');
                app.navigate('user');
            });
        };
        
        window.Pages.showOrderDetails = (orderId) => {
            const order = store.orders.find(o => o.id === orderId);
            if(!order) return;
            
            const itemsHtml = order.items.map(item => `
                <div style="display: flex; gap: 1rem; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">
                    <img src="${item.product.images[0]}" style="width: 60px; height: 60px; border-radius: var(--radius-sm); object-fit: cover;">
                    <div style="flex: 1;">
                        <div style="font-weight: 600;">${item.product.name}</div>
                        <div style="color: var(--text-secondary); font-size: 0.8rem;">Qty: ${item.quantity} | Price: ${utils.formatPrice(item.product.price)}</div>
                    </div>
                    <div style="font-weight: bold;">${utils.formatPrice(item.product.price * item.quantity)}</div>
                </div>
            `).join('');

            UI.showModal({
                title: 'Order Details ' + order.id,
                body: `
                    <div style="margin-bottom: 1.5rem;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span style="color: var(--text-secondary);">Date:</span>
                            <span>${new Date(order.date).toLocaleString()}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span style="color: var(--text-secondary);">Status:</span>
                            <span class="badge ${order.status === 'Processing' ? 'badge-warning' : (order.status === 'Shipped' ? 'badge-primary' : 'badge-success')}">${order.status}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span style="color: var(--text-secondary);">Payment:</span>
                            <span>${order.payment ? order.payment.method : 'Standard Credit Card'}</span>
                        </div>
                    </div>
                    <h4 style="margin-bottom: 1rem;">Items Ordered</h4>
                    <div style="max-height: 300px; overflow-y: auto;">
                        ${itemsHtml}
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 1.25rem; font-weight: bold; margin-top: 1rem; padding-top: 1rem; border-top: 2px solid var(--border-color);">
                        <span>Total:</span>
                        <span class="text-gradient">${utils.formatPrice(order.total * 1.1)}</span>
                    </div>
                `,
                footer: `<button class="btn btn-primary" onclick="UI.closeModal(this.closest('.modal-overlay').id)">Close</button>`
            });
        };
    }
};
