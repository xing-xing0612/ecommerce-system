// Global State Management

class Store {
    constructor() {
        this.cart = utils.storage.get('aura_cart', []);
        this.user = utils.storage.get('aura_user', null);
        this.theme = utils.storage.get('aura_theme', 'dark');
        // Orders & Chats
        this.orders = utils.storage.get('aura_orders', []);
        this.chats = utils.storage.get('aura_chats', []);
        
        // Product Management
        this.products = utils.storage.get('aura_products', window.mockData.products);
        
        // Mock database for users
        this.usersDb = utils.storage.get('aura_users_db', [
            { id: 'u1', email: 'admin@aura.com', password: 'password', name: 'Admin', role: 'admin', avatar: '', phone: '', addresses: [], wishlist: [] },
            { id: 'u2', email: 'customer@aura.com', password: 'password123', name: 'Customer', role: 'customer', avatar: '', phone: '', addresses: [], wishlist: [] }
        ]);
        
        // Fix for legacy users without an ID
        let dbChanged = false;
        this.usersDb.forEach(u => {
            if (u && !u.id) {
                u.id = utils.generateId('U_legacy');
                if (this.user && this.user.email === u.email) {
                    this.user.id = u.id;
                    utils.storage.set('aura_user', this.user);
                }
                dbChanged = true;
            }
        });
        if (dbChanged) {
            utils.storage.set('aura_users_db', this.usersDb);
        }
        
        // Ensure DOM matches initial theme
        document.documentElement.setAttribute('data-theme', this.theme);
        
        // Listen to localStorage changes from other tabs for real-time updates
        window.addEventListener('storage', (e) => {
            if (e.key === 'aura_chats') {
                this.chats = e.newValue ? JSON.parse(e.newValue) : [];
                utils.events.emit('chatUpdated', null);
            } else if (e.key === 'aura_users_db') {
                this.usersDb = e.newValue ? JSON.parse(e.newValue) : [];
                utils.events.emit('usersDbUpdated', this.usersDb);
            } else if (e.key === 'aura_orders') {
                this.orders = e.newValue ? JSON.parse(e.newValue) : [];
            }
        });
    }

    // --- Theme ---
    toggleTheme() {
        this.theme = this.theme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', this.theme);
        utils.storage.set('aura_theme', this.theme);
        utils.events.emit('themeChanged', this.theme);
        return this.theme;
    }

    // --- Cart ---
    addToCart(product, quantity = 1, options = {}) {
        const existingItemIndex = this.cart.findIndex(item => 
            item.product.id === product.id && 
            JSON.stringify(item.options) === JSON.stringify(options)
        );

        if (existingItemIndex > -1) {
            this.cart[existingItemIndex].quantity += quantity;
        } else {
            this.cart.push({
                id: utils.generateId('cart'),
                product,
                quantity,
                options
            });
        }

        this._saveCart();
        UI.toast('Added to cart', 'success');
    }

    removeFromCart(itemId) {
        this.cart = this.cart.filter(item => item.id !== itemId);
        this._saveCart();
    }

    updateCartQuantity(itemId, quantity) {
        if (quantity < 1) return this.removeFromCart(itemId);
        
        const item = this.cart.find(i => i.id === itemId);
        if (item) {
            item.quantity = quantity;
            this._saveCart();
        }
    }

    clearCart() {
        this.cart = [];
        this._saveCart();
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
    }

    getCartCount() {
        return this.cart.reduce((count, item) => count + item.quantity, 0);
    }

    _saveCart() {
        utils.storage.set('aura_cart', this.cart);
        utils.events.emit('cartUpdated', this.cart);
    }

    // --- User & Auth ---
    login(email, password) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const user = this.usersDb.find(u => u && u.email === email && u.password === password);
                if (user) {
                    this.user = {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role,
                        avatar: user.avatar || '',
                        phone: user.phone || '',
                        addresses: user.addresses || [],
                        wishlist: user.wishlist || []
                    };
                    utils.storage.set('aura_user', this.user);
                    utils.events.emit('userUpdated', this.user);
                    resolve(this.user);
                } else {
                    reject(new Error('Invalid email or password'));
                }
            }, 800);
        });
    }

    logout() {
        this.user = null;
        utils.storage.remove('aura_user');
        utils.events.emit('userUpdated', null);
    }

    register(name, email, password) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (name && email && password.length >= 6) {
                    if (this.usersDb.some(u => u && u.email === email)) {
                        reject(new Error('Email is already registered'));
                        return;
                    }
                    
                    const newUser = { 
                        id: utils.generateId('U'), 
                        email, 
                        password, 
                        name, 
                        role: 'customer',
                        avatar: '',
                        phone: '',
                        addresses: [],
                        wishlist: []
                    };
                    this.usersDb.push(newUser);
                    utils.storage.set('aura_users_db', this.usersDb);
                    
                    this.user = {
                        id: newUser.id,
                        name: name,
                        email: email,
                        role: 'customer',
                        avatar: '',
                        phone: '',
                        addresses: [],
                        wishlist: []
                    };
                    utils.storage.set('aura_user', this.user);
                    utils.events.emit('userUpdated', this.user);
                    resolve(this.user);
                } else {
                    reject(new Error('Please fill in all fields (password must be at least 6 characters)'));
                }
            }, 800);
        });
    }
    
    // User Profile Sync
    updateUserProfile(updates) {
        if (!this.user) return;
        // Update active user session
        this.user = { ...this.user, ...updates };
        utils.storage.set('aura_user', this.user);
        
        // Sync to usersDb so admin can see it
        const dbIdx = this.usersDb.findIndex(u => u && u.email === this.user.email);
        if(dbIdx > -1) {
            this.usersDb[dbIdx] = { ...this.usersDb[dbIdx], ...updates };
            utils.storage.set('aura_users_db', this.usersDb);
            utils.events.emit('usersDbUpdated', this.usersDb);
        }
        
        utils.events.emit('userUpdated', this.user);
    }
    
    addAddress(address) {
        if (!this.user) return;
        const addrs = this.user.addresses || [];
        addrs.push({ id: utils.generateId('A'), ...address });
        this.updateUserProfile({ addresses: addrs });
    }
    
    updateAddress(id, updatedAddr) {
        if (!this.user || !this.user.addresses) return;
        const addrs = this.user.addresses.map(a => a.id === id ? { ...a, ...updatedAddr } : a);
        this.updateUserProfile({ addresses: addrs });
    }
    
    deleteAddress(id) {
        if (!this.user || !this.user.addresses) return;
        const addrs = this.user.addresses.filter(a => a.id !== id);
        this.updateUserProfile({ addresses: addrs });
    }
    
    toggleWishlist(productId) {
        if (!this.user) return;
        let wl = this.user.wishlist || [];
        if (wl.includes(productId)) {
            wl = wl.filter(id => id !== productId);
            if(window.UI) window.UI.toast('Removed from Wishlist', 'info');
        } else {
            wl.push(productId);
            if(window.UI) window.UI.toast('Added to Wishlist', 'success');
        }
        this.updateUserProfile({ wishlist: wl });
    }
    
    // --- User Management (Admin) ---
    addUser(userData) {
        userData.id = utils.generateId('U');
        this.usersDb.push(userData);
        utils.storage.set('aura_users_db', this.usersDb);
        utils.events.emit('usersDbUpdated', this.usersDb);
    }
    
    updateUser(email, updatedData) {
        const idx = this.usersDb.findIndex(u => u && u.email === email);
        if (idx > -1) {
            this.usersDb[idx] = { ...this.usersDb[idx], ...updatedData };
            utils.storage.set('aura_users_db', this.usersDb);
            utils.events.emit('usersDbUpdated', this.usersDb);
            
            // If the currently logged in user was updated by admin
            if (this.user && this.user.email === email) {
                this.user = { ...this.user, ...updatedData };
                utils.storage.set('aura_user', this.user);
                utils.events.emit('userUpdated', this.user);
            }
        }
    }
    
    deleteUser(email) {
        this.usersDb = this.usersDb.filter(u => u && u.email !== email);
        utils.storage.set('aura_users_db', this.usersDb);
        utils.events.emit('usersDbUpdated', this.usersDb);
    }
    
    // --- Chat Management (Support) ---
    getChat(userId, createIfNone = true) {
        // Always refresh from storage to prevent stale state issues across tabs
        this.chats = utils.storage.get('aura_chats', []);
        
        // Find ALL active chats for this user to fix corrupted states
        let activeChats = this.chats.filter(c => c && c.userId === userId && c.status === 'active');
        let chat = activeChats[0];

        // If there are duplicates, end the older ones to clean up
        if (activeChats.length > 1) {
            for (let i = 1; i < activeChats.length; i++) {
                activeChats[i].status = 'ended';
            }
            utils.storage.set('aura_chats', this.chats);
        }

        if (!chat && createIfNone) {
            chat = { id: utils.generateId('C'), userId, status: 'active', messages: [] };
            // Unshift to make it the FIRST chat found by admin sidebar
            this.chats.unshift(chat);
            utils.storage.set('aura_chats', this.chats);
        }
        return chat;
    }

    sendMessage(userId, text, sender) {
        // Get the latest chat (this also reloads this.chats from storage)
        let chat = this.getChat(userId);
        chat.messages.push({
            id: utils.generateId('M'),
            sender, // 'user' or 'admin'
            text,
            timestamp: Date.now()
        });
        utils.storage.set('aura_chats', this.chats);
        utils.events.emit('chatUpdated', chat);
    }

    endChat(userId) {
        this.chats = utils.storage.get('aura_chats', []);
        let chat = this.chats.find(c => c && c.userId === userId && c.status === 'active');
        if (chat) {
            chat.status = 'ended';
            utils.storage.set('aura_chats', this.chats);
            utils.events.emit('chatUpdated', chat);
        }
    }
    
    deleteUser(email) {
        if (email === 'admin@aura.com') return; // protect default admin
        this.usersDb = this.usersDb.filter(u => u && u.email !== email);
        utils.storage.set('aura_users_db', this.usersDb);
        utils.events.emit('usersDbUpdated', this.usersDb);
    }

    // --- Product Management ---
    addProduct(product) {
        this.products.unshift(product);
        utils.storage.set('aura_products', this.products);
        utils.events.emit('productsUpdated', this.products);
    }

    updateProduct(id, updatedData) {
        const index = this.products.findIndex(p => p.id === id);
        if (index > -1) {
            this.products[index] = { ...this.products[index], ...updatedData };
            utils.storage.set('aura_products', this.products);
            utils.events.emit('productsUpdated', this.products);
        }
    }

    deleteProduct(id) {
        this.products = this.products.filter(p => p.id !== id);
        utils.storage.set('aura_products', this.products);
        utils.events.emit('productsUpdated', this.products);
    }

    // --- Orders Management ---
    updateOrderStatus(orderId, status) {
        const order = this.orders.find(o => o.id === orderId);
        if (order) {
            order.status = status;
            utils.storage.set('aura_orders', this.orders);
            utils.events.emit('orderUpdated', this.orders);
        }
    }

    logout() {
        this.user = null;
        utils.storage.remove('aura_user');
        utils.events.emit('userUpdated', null);
    }

    // --- Orders ---
    createOrder(shippingInfo, paymentInfo) {
        const order = {
            id: utils.generateId('ORD'),
            date: new Date().toISOString(),
            items: [...this.cart],
            total: this.getCartTotal(),
            status: 'Processing',
            shipping: shippingInfo
        };

        this.orders.push(order);
        utils.storage.set('aura_orders', this.orders);
        this.clearCart();
        utils.events.emit('orderCreated', order);
        return order;
    }
}

window.store = new Store();
