// UI Components and Renderers

const UI = {
    // --- Toast Notifications ---
    toast(message, type = 'info', duration = 3000) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast ${type} toast-enter`;
        
        let iconClass = 'fa-info-circle';
        if (type === 'success') iconClass = 'fa-check-circle';
        if (type === 'error') iconClass = 'fa-exclamation-circle';
        if (type === 'warning') iconClass = 'fa-exclamation-triangle';

        toast.innerHTML = `
            <div class="toast-icon">
                <i class="fa-solid ${iconClass}"></i>
            </div>
            <div class="toast-content">
                <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-times"></i>
            </button>
        `;

        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('toast-enter');
            toast.classList.add('toast-exit');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    // --- Modals ---
    showModal(options) {
        const container = document.getElementById('modal-container');
        if (!container) return;

        const modalId = utils.generateId('modal');
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay active';
        overlay.id = modalId;

        const content = `
            <div class="modal">
                <div class="modal-header">
                    <h3 class="modal-title">${options.title}</h3>
                    <button class="modal-close" onclick="UI.closeModal('${modalId}')">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${options.body}
                </div>
                ${options.footer ? `
                <div class="modal-footer">
                    ${options.footer}
                </div>
                ` : ''}
            </div>
        `;

        overlay.innerHTML = content;
        
        // Close on outside click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) this.closeModal(modalId);
        });

        container.appendChild(overlay);

        // Execute any after-render scripts
        if (typeof options.onRender === 'function') {
            options.onRender(overlay);
        }

        return modalId;
    },

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        }
    },

    confirm(message, onConfirm, type = 'danger') {
        const tempId = utils.generateId('confirm');
        this.showModal({
            title: 'Confirm Action',
            body: `<p style="margin:0;">${message}</p>`,
            footer: `
                <button class="btn btn-outline cancel-btn">Cancel</button>
                <button class="btn btn-${type} confirm-btn">Confirm</button>
            `,
            onRender: (overlay) => {
                overlay.querySelector('.cancel-btn').addEventListener('click', () => {
                    this.closeModal(overlay.id);
                });
                overlay.querySelector('.confirm-btn').addEventListener('click', () => {
                    this.closeModal(overlay.id);
                    if (typeof onConfirm === 'function') onConfirm();
                });
            }
        });
    },

    // --- Product Card ---
    renderProductCard(product) {
        const hasDiscount = product.originalPrice && product.originalPrice > product.price;
        const discountBadge = hasDiscount 
            ? `<span class="badge badge-danger product-badge">-${utils.calculateDiscount(product.price, product.originalPrice)}%</span>`
            : product.isNew 
                ? `<span class="badge badge-success product-badge">New</span>` 
                : '';

        const catName = window.mockData.categories.find(c => c.id === product.category)?.name || '';
        const isWishlisted = store.user && store.user.wishlist && store.user.wishlist.includes(product.id);
        const heartClass = isWishlisted ? 'fa-solid fa-heart' : 'fa-regular fa-heart';
        const heartColor = isWishlisted ? 'color: var(--danger);' : 'color: var(--text-secondary);';

        return `
            <div class="card product-card hover-lift" data-id="${product.id}">
                <button class="wishlist-btn hover-scale" onclick="event.stopPropagation(); if(!store.user){ UI.showAuthModal(); return; } store.toggleWishlist('${product.id}'); const i = this.querySelector('i'); if(i.classList.contains('fa-solid')){ i.classList.replace('fa-solid', 'fa-regular'); i.style.color='var(--text-secondary)'; } else { i.classList.replace('fa-regular', 'fa-solid'); i.style.color='var(--danger)'; }" title="Toggle Wishlist" style="position:absolute; top:1rem; right:1rem; background:var(--bg-primary); border-radius:50%; width:36px; height:36px; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 6px rgba(0,0,0,0.1); border:none; cursor:pointer; z-index:2; transition: transform 0.2s ease;">
                    <i class="${heartClass}" style="${heartColor} font-size: 1.1rem; transition: color 0.3s ease;"></i>
                </button>
                <div class="product-img-wrapper cursor-pointer" onclick="app.navigate('product', {id: '${product.id}'})">
                    ${discountBadge}
                    <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
                </div>
                <div class="product-info">
                    <span class="product-category">${catName}</span>
                    <h4 class="product-title cursor-pointer" onclick="app.navigate('product', {id: '${product.id}'})">${product.name}</h4>
                    <div class="product-rating">
                        <i class="fa-solid fa-star"></i> ${product.rating} (${product.reviews})
                    </div>
                    <div class="product-price-row">
                        <div>
                            <span class="product-price ${hasDiscount ? 'discounted' : ''}">${utils.formatPrice(product.price)}</span>
                            ${hasDiscount ? `<span class="product-price-old">${utils.formatPrice(product.originalPrice)}</span>` : ''}
                        </div>
                        <button class="btn btn-icon btn-primary hover-scale add-to-cart-btn" data-id="${product.id}" title="Add to Cart">
                            <i class="fa-solid fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    // --- Login/Register Modal ---
    showAuthModal() {
        this.showModal({
            title: 'Welcome to Aura',
            body: `
                <div class="auth-tabs" style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
                    <button class="btn btn-ghost active" id="tab-login" style="flex:1; border-bottom: 2px solid var(--primary); border-radius:0;">Login</button>
                    <button class="btn btn-ghost" id="tab-register" style="flex:1; border-radius:0;">Register</button>
                </div>
                
                <form id="auth-form" onsubmit="event.preventDefault();">
                    <div class="form-group hidden" id="name-group">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="auth-name" placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="auth-email" required placeholder="name@example.com" value="customer@aura.com">
                    </div>
                    <div class="form-group" style="position: relative;">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" id="auth-password" required placeholder="••••••••" value="password123" style="padding-right: 40px;">
                        <button type="button" id="toggle-password" style="position: absolute; right: 10px; top: 38px; color: var(--text-secondary); background: transparent; border: none; cursor: pointer;">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full" id="auth-submit-btn">
                        <span>Sign In</span>
                    </button>
                </form>
                
                <div style="margin-top: 1.5rem; text-align: center;">
                    <p class="text-sm" style="color: var(--text-secondary)">Demo Accounts:</p>
                    <p class="text-sm">Admin: admin@aura.com / password</p>
                </div>
            `,
            onRender: (modalEl) => {
                const form = modalEl.querySelector('#auth-form');
                const btn = modalEl.querySelector('#auth-submit-btn');
                const btnText = btn.querySelector('span');
                const togglePwdBtn = modalEl.querySelector('#toggle-password');
                const pwdInput = modalEl.querySelector('#auth-password');
                
                const tabLogin = modalEl.querySelector('#tab-login');
                const tabRegister = modalEl.querySelector('#tab-register');
                const nameGroup = modalEl.querySelector('#name-group');
                const authName = modalEl.querySelector('#auth-name');
                
                let isLoginMode = true;

                // Tab switching logic
                tabLogin.addEventListener('click', () => {
                    isLoginMode = true;
                    tabLogin.classList.add('active');
                    tabLogin.style.borderBottom = '2px solid var(--primary)';
                    tabRegister.classList.remove('active');
                    tabRegister.style.borderBottom = 'none';
                    nameGroup.classList.add('hidden');
                    authName.removeAttribute('required');
                    btnText.textContent = 'Sign In';
                });

                tabRegister.addEventListener('click', () => {
                    isLoginMode = false;
                    tabRegister.classList.add('active');
                    tabRegister.style.borderBottom = '2px solid var(--primary)';
                    tabLogin.classList.remove('active');
                    tabLogin.style.borderBottom = 'none';
                    nameGroup.classList.remove('hidden');
                    authName.setAttribute('required', 'true');
                    btnText.textContent = 'Create Account';
                });

                if (togglePwdBtn && pwdInput) {
                    togglePwdBtn.addEventListener('click', () => {
                        const type = pwdInput.getAttribute('type') === 'password' ? 'text' : 'password';
                        pwdInput.setAttribute('type', type);
                        togglePwdBtn.innerHTML = type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
                    });
                }
                
                form.addEventListener('submit', async () => {
                    const email = document.getElementById('auth-email').value;
                    const pass = document.getElementById('auth-password').value;
                    const name = authName.value;
                    
                    btnText.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;"></div>';
                    btn.disabled = true;

                    try {
                        if (isLoginMode) {
                            await store.login(email, pass);
                            this.toast('Successfully logged in!', 'success');
                        } else {
                            await store.register(name, email, pass);
                            this.toast('Account created successfully!', 'success');
                        }
                        
                        this.closeModal(modalEl.id);
                        if(store.user.role === 'admin') {
                            app.navigate('admin');
                        } else if(app.currentRoute === 'checkout') {
                            // Refresh checkout page if logged in during checkout
                            app.navigate('checkout');
                        } else {
                            app.navigate('user');
                        }
                    } catch (e) {
                        this.toast(e.message, 'error');
                        btnText.textContent = isLoginMode ? 'Sign In' : 'Create Account';
                        btn.disabled = false;
                    }
                });
            }
        });
    }
};

window.UI = UI;
